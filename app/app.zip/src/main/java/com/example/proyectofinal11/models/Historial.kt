package com.example.proyectofinal11.models

data class Historial(
    val titulo: String,
    val usuario: String,
    val fecha: String,
    val precio: String,
    val estado: String
)
